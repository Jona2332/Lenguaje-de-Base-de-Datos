/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConexionSQLDev;

import MainClasses.Puestos;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author jonha
 */
public class PuestoDB {
    
      public static void insertarPuesto(Puestos puesto) {
    Connection conn = null;
    CallableStatement stmt = null;
    try {
      conn = DBConn.getConnection();
      stmt = conn.prepareCall("{call insertar_puesto(?, ?, ?)}");
      stmt.setInt(1, puesto.getId_puesto());
      stmt.setString(2, puesto.getNombre_puesto());
      stmt.setString(3, puesto.getDescripcion_puesto());
      stmt.executeUpdate();
      System.out.println("Puesto insertado correctamente.");
    } catch (SQLException ex) {
      System.out.println("Error al insertar puesto: " + ex.getMessage());
    } finally {
      try {
        if (stmt != null) stmt.close();
        if (conn != null) conn.close();
      } catch (SQLException ex) {
        System.out.println("Error al cerrar la conexión: " + ex.getMessage());
      }
    }
  }
  
  // Obtener la lista de todos los puestos
  public  ArrayList<Puestos> listarPuestos() {
    Connection conn = null;
    CallableStatement stmt = null;
    ResultSet rs = null;
    ArrayList<Puestos> puestos = new ArrayList<>();
    try {
      conn = DBConn.getConnection();
      stmt = conn.prepareCall("{call listar_puestos}");
      stmt.execute();
      rs = stmt.getResultSet();
      while (rs.next()) {
        Puestos puesto = new Puestos();
        puesto.setId_puesto(rs.getInt("id_puesto"));
        puesto.setNombre_puesto(rs.getString("nombre_puesto"));
        puesto.setDescripcion_puesto(rs.getString("descripcion_puesto"));
        puestos.add(puesto);
      }
    } catch (SQLException ex) {
      System.out.println("Error al listar puestos: " + ex.getMessage());
    } finally {
      try {
        if (rs != null) rs.close();
        if (stmt != null) stmt.close();
        if (conn != null) conn.close();
      } catch (SQLException ex) {
        System.out.println("Error al cerrar la conexión: " + ex.getMessage());
      }
    }
    return puestos;
  }
    
    public static void modificarPuesto(Puestos puesto) {
    Connection conn = null;
    CallableStatement stmt = null;
    try {
        conn = DBConn.getConnection();
        stmt = conn.prepareCall("{call modificar_puesto(?, ?, ?)}");
        stmt.setInt(1, puesto.getId_puesto());
        stmt.setString(2, puesto.getNombre_puesto());
        stmt.setString(3, puesto.getDescripcion_puesto());
        stmt.executeUpdate();
        System.out.println("Puesto modificado correctamente.");
    } catch (SQLException ex) {
        System.out.println("Error al modificar puesto: " + ex.getMessage());
    } finally {
        try {
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        } catch (SQLException ex) {
            System.out.println("Error al cerrar la conexión: " + ex.getMessage());
        }
    }
}

public static void eliminarPuesto(int idPuesto) {
    Connection conn = null;
    CallableStatement stmt = null;
    try {
        conn = DBConn.getConnection();
        stmt = conn.prepareCall("{call eliminar_puesto(?)}");
        stmt.setInt(1, idPuesto);
        stmt.executeUpdate();
        System.out.println("Puesto eliminado correctamente.");
    } catch (SQLException ex) {
        System.out.println("Error al eliminar puesto: " + ex.getMessage());
    } finally {
        try {
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        } catch (SQLException ex) {
            System.out.println("Error al cerrar la conexión: " + ex.getMessage());
        }
    }
}
}
