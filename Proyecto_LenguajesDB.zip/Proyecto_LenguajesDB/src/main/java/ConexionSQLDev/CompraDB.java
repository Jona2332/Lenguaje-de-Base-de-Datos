/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConexionSQLDev;

import MainClasses.Compras;
import MainClasses.DetalleCompras;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.jdbc.OracleTypes;

/**
 *
 * @author jonha
 */
public class CompraDB {
    public static void insertarCompra(Compras compra) {
        try {
            Connection conn = DBConn.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT MAX(id_compra) AS max_id FROM Compra");
            int maxId = rs.next() ? rs.getInt("max_id") : 0;
            int idCompra = maxId + 1;
            CallableStatement cs = conn.prepareCall("{call insertar_compra(?,?,?,?)}");
            cs.setInt(1, compra.getId_compra());
            cs.setInt(2, compra.getId_empleado());
            cs.setInt(3, compra.getId_empresa());
            cs.setFloat(4, compra.getMonto());
            cs.setString(5, compra.getFecha());
            cs.execute();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
}
        public static void modificarCompra(Compras compra) {
        try {
            Connection conn = DBConn.getConnection();
            CallableStatement cs = conn.prepareCall("{call modificar_compra(?,?,?,?,?)}");
            cs.setInt(1, compra.getId_compra());
            cs.setInt(2, compra.getId_empleado());
            cs.setInt(3, compra.getId_empresa());
            cs.setFloat(4, compra.getMonto());
            cs.setString(5, compra.getFecha());
            cs.execute();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
        
        public ArrayList<Compras> ListarCompras(){
        ArrayList<Compras> compra = new ArrayList();
        try {
            Connection cnn = DBConn.getConnection();
            CallableStatement cst = cnn.prepareCall("{call listar_compras(?)}");
            cst.registerOutParameter(1, OracleTypes.CURSOR);
            cst.execute();
            ResultSet rs = (ResultSet)cst.getObject(1);
            while (rs.next()){
                Compras co = new Compras();
                co.setId_compra(rs.getInt("id_compra"));
                co.setId_empleado(rs.getInt("id_empleado"));
                co.setId_empresa(rs.getInt("id_empresa"));
                co.setMonto(rs.getFloat("monto"));
                co.setFecha(rs.getString("fecha"));
                compra.add(co);
            }
            cnn.close();
        } catch (SQLException ex) {
            Logger.getLogger(DetalleCompraDB.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error al listar detalles de compras.");
        }
        return compra;
    }
        public static void eliminarCompra(int idCompra) {
        try {
            Connection conn = DBConn.getConnection();
            CallableStatement cs = conn.prepareCall("{call eliminar_compra(?)}");
            cs.setInt(1, idCompra);
            cs.execute();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
