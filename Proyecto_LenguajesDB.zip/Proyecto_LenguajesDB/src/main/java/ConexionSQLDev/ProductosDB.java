/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConexionSQLDev;

import MainClasses.Clientes;
import MainClasses.Productos;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import oracle.jdbc.OracleTypes;

/**
 *
 * @author jonha
 */
public class ProductosDB {
       public ArrayList<Productos> ListProductos(){
    ArrayList<Productos> producto = new ArrayList();
    try{
        Connection cnn = DBConn.getConnection();
        CallableStatement cs = cnn.prepareCall("{call ListarProductos(?)}");
        cs.registerOutParameter(1, OracleTypes.CURSOR);
        cs.execute();
        ResultSet rs = (ResultSet)cs.getObject(1);
        while (rs.next()){
            Productos pd = new Productos();
            pd.setCodigo_producto(rs.getInt("codigo_producto"));
            pd.setNombre_producto(rs.getString("nombre_producto"));
            pd.setPrecio_compra(rs.getFloat("precio_compra"));
            producto.add(pd);
        }
    }catch(SQLException ex){
        System.out.println(ex.getMessage());
        System.out.println("Error en la lista");
    }
    return producto;
    }
    //Insertar datos clientes a Oracle
    public void insertarProductos(Productos producto){
        try{
        Connection cnn = DBConn.getConnection();
        CallableStatement cs = cnn.prepareCall("{call InsertarProducto(?, ?, ?)}");
        cs.setInt(1, producto.getCodigo_producto());
        cs.setString(2, producto.getNombre_producto());
        cs.setFloat(3, producto.getPrecio_compra());
        cs.executeUpdate();
        }catch(SQLException ex){
        System.out.println(ex.getMessage());
        System.out.println("Error en la insercion");
        }
    }
   
    // Actualizar datos de un cliente en Oracle
    public void actualizarProducto(Productos producto) {
        try {
            Connection cnn = DBConn.getConnection();
            CallableStatement cs = cnn.prepareCall("{call ModificarProducto(?, ?, ?)}");
            cs.setInt(1, producto.getCodigo_producto());
            cs.setString(2, producto.getNombre_producto());
            cs.setFloat(3, producto.getPrecio_compra());
            cs.executeUpdate();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            System.out.println("Error en la actualización");
        }
    }
        // Eliminar un cliente en Oracle
    public void eliminarProducto(int codigo_producto) {
        try {
            Connection cnn = DBConn.getConnection();
            CallableStatement cs = cnn.prepareCall("{call EliminarProducto(?)}");
            cs.setInt(1, codigo_producto);
            cs.executeUpdate();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            System.out.println("Error en la eliminación");
        }
    }
}
