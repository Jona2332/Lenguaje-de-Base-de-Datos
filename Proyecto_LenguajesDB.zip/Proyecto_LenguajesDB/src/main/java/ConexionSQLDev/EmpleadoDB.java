/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConexionSQLDev;

import MainClasses.Empleados;
import MainClasses.Puestos;
import ConexionSQLDev.PuestoDB;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author jonha
 */
public class EmpleadoDB {
    
    public static void insertarEmpleado(Empleados empleado) {
    Connection conn = null;
    CallableStatement stmt = null;
    try {
        conn = DBConn.getConnection();
        stmt = conn.prepareCall("{call insertar_empleado(?, ?, ?, ?, ?)}");
        stmt.setString(1, empleado.getNombre());
        stmt.setString(2, empleado.getPrimer_apellido());
        stmt.setString(3, empleado.getSegundo_apellido());
        stmt.setFloat(4, empleado.getSalario());
        stmt.setInt(5, empleado.getId_puesto());
        stmt.executeUpdate();
        System.out.println("Empleado insertado correctamente.");
    } catch (SQLException ex) {
        System.out.println("Error al insertar empleado: " + ex.getMessage());
    } finally {
        try {
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        } catch (SQLException ex) {
            System.out.println("Error al cerrar la conexión: " + ex.getMessage());
        }
    }
}
    
    public static void modificarEmpleado(Empleados empleado) {
    Connection conn = null;
    CallableStatement stmt = null;
    try {
        conn = DBConn.getConnection();
        stmt = conn.prepareCall("{call modificar_empleado(?, ?, ?, ?, ?, ?)}");
        stmt.setInt(1, empleado.getId_empleado());
        stmt.setString(2, empleado.getNombre());
        stmt.setString(3, empleado.getPrimer_apellido());
        stmt.setString(4, empleado.getSegundo_apellido());
        stmt.setFloat(5, empleado.getSalario());
        stmt.setInt(6, empleado.getId_puesto());
        stmt.executeUpdate();
        System.out.println("Empleado modificado correctamente.");
    } catch (SQLException ex) {
        System.out.println("Error al modificar empleado: " + ex.getMessage());
    } finally {
        try {
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        } catch (SQLException ex) {
            System.out.println("Error al cerrar la conexión: " + ex.getMessage());
        }
    }
}
    
    public static void eliminarEmpleado(int idEmpleado) {
    Connection conn = null;
    CallableStatement stmt = null;
    try {
        conn = DBConn.getConnection();
        stmt = conn.prepareCall("{call eliminar_empleado(?)}");
        stmt.setInt(1, idEmpleado);
        stmt.executeUpdate();
        System.out.println("Empleado eliminado correctamente.");
    } catch (SQLException ex) {
        System.out.println("Error al eliminar empleado: " + ex.getMessage());
    } finally {
        try {
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        } catch (SQLException ex) {
            System.out.println("Error al cerrar la conexión: " + ex.getMessage());
        }
    }
}
    
    public ArrayList<Empleados> listarEmpleados() {
    ArrayList<Empleados> empleados = new ArrayList<>();
    try{
    Connection cnn = DBConn.getConnection();
    CallableStatement cs = cnn.prepareCall("{ call listar_empleados }");
    ResultSet rs = cs.executeQuery();
    while (rs.next()) {
        Empleados empleado = new Empleados();
        empleado.setId_empleado(rs.getInt("id_empleado"));
        empleado.setNombre(rs.getString("nombre"));
        empleado.setPrimer_apellido(rs.getString("primer_apellido"));
        empleado.setSegundo_apellido(rs.getString("segundo_apellido"));
        empleado.setSalario(rs.getFloat("salario"));
        empleado.setId_puesto(rs.getInt("id_puesto"));
        empleados.add(empleado);
    }
    }catch(SQLException ex){
        System.out.println(ex.getMessage());
        System.out.println("Error en la lista");}
    return empleados;
    }
}