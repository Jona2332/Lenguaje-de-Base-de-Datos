/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConexionSQLDev;

import MainClasses.Clientes;
import MainClasses.DetalleCompras;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.jdbc.OracleTypes;

/**
 *
 * @author jonha
 */
public class DetalleCompraDB {
    public static void insertarDetalleCompra(int idCompra, int codigoProducto, int cantidad, float precioCompra) {
    try {
        Connection cnn = DBConn.getConnection();
        CallableStatement cst = cnn.prepareCall("{call insertar_detalle_compra(?, ?, ?, ?, ?)}");

        // Validar si el idDetalleCompra ya existe en la base de datos
        int idDetalleCompra = obtenerIdDetalleCompra();

        cst.setInt(1, idDetalleCompra);
        cst.setInt(2, idCompra);
        cst.setInt(3, codigoProducto);
        cst.setInt(4, cantidad);
        cst.setFloat(5, precioCompra);
        cst.execute();
        cnn.close();
        System.out.println("Detalle de compra insertado correctamente.");
    } catch (SQLException ex) {
        Logger.getLogger(DetalleCompraDB.class.getName()).log(Level.SEVERE, null, ex);
        System.out.println("Error al insertar detalle de compra.");
    }
}

public static int obtenerIdDetalleCompra() throws SQLException {
    Connection cnn = DBConn.getConnection();
    CallableStatement cst = cnn.prepareCall("{call obtener_id_detalle_compra}");
    ResultSet rs = cst.executeQuery();
    int idDetalleCompra = 1;
    if (rs.next()) {
        idDetalleCompra = rs.getInt(1) + 1;
    }
    cnn.close();
    return idDetalleCompra;
}
   public static void modificarDetalleCompra(int idDetalleCompra, int idCompra, int codigoProducto, int cantidad, float precioCompra) {
        try {
            Connection cnn = DBConn.getConnection();
            CallableStatement cst = cnn.prepareCall("{call modificar_detalle_compra(?, ?, ?, ?, ?)}");
            cst.setInt(1, idDetalleCompra);
            cst.setInt(2, idCompra);
            cst.setInt(3, codigoProducto);
            cst.setInt(4, cantidad);
            cst.setFloat(5, precioCompra);
            cst.execute();
            cnn.close();
            System.out.println("Detalle de compra modificado correctamente.");
        } catch (SQLException ex) {
            Logger.getLogger(DetalleCompraDB.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error al modificar detalle de compra.");
        }
    }
    
    public static void eliminarDetalleCompra(int idDetalleCompra) {
        try {
            Connection cnn = DBConn.getConnection();
            CallableStatement cst = cnn.prepareCall("{call eliminar_detalle_compra(?)}");
            cst.setInt(1, idDetalleCompra);
            cst.execute();
            cnn.close();
            System.out.println("Detalle de compra eliminado correctamente.");
        } catch (SQLException ex) {
            Logger.getLogger(DetalleCompraDB.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error al eliminar detalle de compra.");
        }
    }
    
    
    public ArrayList<DetalleCompras> ListDetalleCompras(){
        ArrayList<DetalleCompras> detalleCompra = new ArrayList();
        try {
            Connection cnn = DBConn.getConnection();
            CallableStatement cst = cnn.prepareCall("{call listar_detalle_compras(?)}");
            cst.registerOutParameter(1, OracleTypes.CURSOR);
            cst.execute();
            ResultSet rs = (ResultSet)cst.getObject(1);
            while (rs.next()){
                DetalleCompras dc = new DetalleCompras();
                dc.setId_detalle_compra(rs.getInt("id_detalle_compra"));
                dc.setId_compra(rs.getInt("id_compra"));
                dc.setCodigo_producto(rs.getInt("codigo_producto"));
                dc.setCantidad(rs.getInt("cantidad"));
                dc.setPrecio_compra(rs.getFloat("precio_compra"));
                detalleCompra.add(dc);
            }
            cnn.close();
        } catch (SQLException ex) {
            Logger.getLogger(DetalleCompraDB.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error al listar detalles de compras.");
        }
        return detalleCompra;
    }
}
