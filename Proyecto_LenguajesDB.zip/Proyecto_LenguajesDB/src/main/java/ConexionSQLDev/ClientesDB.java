/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConexionSQLDev;

import MainClasses.Clientes;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import oracle.jdbc.OracleTypes;

/**
 *
 * @author jonha
 * Listado de clientes en Base de datos
 */
public class ClientesDB {

       
    public ArrayList<Clientes> ListClientes(){
    ArrayList<Clientes> cliente = new ArrayList();
    try{
        Connection cnn = DBConn.getConnection();
        CallableStatement cs = cnn.prepareCall("{call listar_clientes(?)}");
        cs.registerOutParameter(1, OracleTypes.CURSOR);
        cs.execute();
        ResultSet rs = (ResultSet)cs.getObject(1);
        while (rs.next()){
            Clientes cl = new Clientes();
            cl.setId_cliente(rs.getInt("id_cliente"));
            cl.setCedula(rs.getString("cedula"));
            cl.setNombre(rs.getString("nombre"));
            cl.setPrimer_apellido(rs.getString("primer_apellido"));
            cl.setSegundo_apellido(rs.getString("segundo_apellido"));
            cl.setDireccion(rs.getString("direccion"));
            cl.setTelefono(rs.getString("telefono"));
            cliente.add(cl);
        }
    }catch(SQLException ex){
        System.out.println(ex.getMessage());
        System.out.println("Error en la lista");
    }
    return cliente;
    }
    //Insertar datos clientes a Oracle
    public void insertarClientes(Clientes cliente){
        try{
        Connection cnn = DBConn.getConnection();
        CallableStatement cs = cnn.prepareCall("{call insertar_cliente(?, ?, ?, ?, ?, ?, ?)}");
        cs.setInt(1, cliente.getId_cliente());
        cs.setString(2, cliente.getCedula());
        cs.setString(3, cliente.getNombre());
        cs.setString(4, cliente.getPrimer_apellido());
        cs.setString(5, cliente.getSegundo_apellido());
        cs.setString(6, cliente.getDireccion());
        cs.setString(7, cliente.getTelefono());
        cs.executeUpdate();
        }catch(SQLException ex){
        System.out.println(ex.getMessage());
        System.out.println("Error en la insercion");
        }
    }
   
    // Actualizar datos de un cliente en Oracle
    public void actualizarCliente(Clientes cliente) {
        try {
            Connection cnn = DBConn.getConnection();
            CallableStatement cs = cnn.prepareCall("{call modificar_cliente(?, ?, ?, ?, ?, ?, ?)}");
            cs.setInt(1, cliente.getId_cliente());
            cs.setString(2, cliente.getNombre());
            cs.setString(3, cliente.getCedula());
            cs.setString(4, cliente.getPrimer_apellido());
            cs.setString(5, cliente.getSegundo_apellido());
            cs.setString(6, cliente.getDireccion());
            cs.setString(7, cliente.getTelefono());
            cs.executeUpdate();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            System.out.println("Error en la actualización");
        }
    }
        // Eliminar un cliente en Oracle
    public void eliminarCliente(int id_cliente) {
        try {
            Connection cnn = DBConn.getConnection();
            CallableStatement cs = cnn.prepareCall("{call eliminar_cliente(?)}");
            cs.setInt(1, id_cliente);
            cs.executeUpdate();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            System.out.println("Error en la eliminación");
        }
    }
}
