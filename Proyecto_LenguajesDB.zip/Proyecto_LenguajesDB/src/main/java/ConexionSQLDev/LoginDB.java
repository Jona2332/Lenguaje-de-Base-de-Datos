/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConexionSQLDev;
import static ConexionSQLDev.DBConn.getConnection;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import javax.swing.JOptionPane;
import oracle.jdbc.OracleTypes;
/**
 *
 * @author jonha
 */
public class LoginDB {

public static boolean validateUser(String username, String password, String selectedRole) {
    try {
        Connection conn = getConnection();
        CallableStatement stmt = conn.prepareCall("{call login_proc(?, ?, ?)}");
        stmt.setString(1, username);
        stmt.setString(2, password);
        stmt.registerOutParameter(3, Types.VARCHAR);
        stmt.execute();
        
        String dbRole = stmt.getString(3);
        
        conn.close();
        
        return selectedRole.equals(dbRole);
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        return false;
        }
    }
}
