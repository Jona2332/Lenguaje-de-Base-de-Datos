/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConexionSQLDev;

import MainClasses.Empresas;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author jonha
 */
public class EmpresaDB {
    public static void insertarEmpresa(Empresas empresa) {
    Connection conn = null;
    CallableStatement stmt = null;
    try {
        conn = DBConn.getConnection();
        stmt = conn.prepareCall("{call insertar_empresa(?, ?, ?)}");
        stmt.setInt(1, empresa.getId_empresa());
        stmt.setString(2, empresa.getNombre_empresa());
        stmt.setString(3, empresa.getUbicacion_empresa());
        stmt.executeUpdate();
        System.out.println("Empresa insertada correctamente.");
    } catch (SQLException ex) {
        System.out.println("Error al insertar empresa: " + ex.getMessage());
    } finally {
        try {
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        } catch (SQLException ex) {
            System.out.println("Error al cerrar la conexión: " + ex.getMessage());
        }
    }
}
    public static void modificarEmpresa(Empresas empresa) {
    Connection conn = null;
    CallableStatement stmt = null;
    try {
        conn = DBConn.getConnection();
        stmt = conn.prepareCall("{call modificar_empresa(?, ?, ?)}");
        stmt.setInt(1, empresa.getId_empresa());
        stmt.setString(2, empresa.getNombre_empresa());
        stmt.setString(3, empresa.getUbicacion_empresa());
        stmt.executeUpdate();
        System.out.println("Empresa modificada correctamente.");
    } catch (SQLException ex) {
        System.out.println("Error al modificar empresa: " + ex.getMessage());
    } finally {
        try {
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        } catch (SQLException ex) {
            System.out.println("Error al cerrar la conexión: " + ex.getMessage());
        }
    }
}
    
    public static void eliminarEmpresa(int idEmpresa) {
    Connection conn = null;
    CallableStatement stmt = null;
    try {
        conn = DBConn.getConnection();
        stmt = conn.prepareCall("{call eliminar_empresa(?)}");
        stmt.setInt(1, idEmpresa);
        stmt.executeUpdate();
        System.out.println("Empresa eliminada correctamente.");
    } catch (SQLException ex) {
        System.out.println("Error al eliminar empresa: " + ex.getMessage());
    } finally {
        try {
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        } catch (SQLException ex) {
            System.out.println("Error al cerrar la conexión: " + ex.getMessage());
        }
    }
}

public ArrayList<Empresas> listarEmpresas() {
    ArrayList<Empresas> empresas = new ArrayList<>();
    Connection conn = null;
    CallableStatement stmt = null;
    ResultSet rs = null;
    try {
        conn = DBConn.getConnection();
        stmt = conn.prepareCall("{call listar_empresas}");
        rs = stmt.executeQuery();
        while (rs.next()) {
            int idEmpresa = rs.getInt("id_empresa");
            String nombreEmpresa = rs.getString("nombre_empresa");
            String ubicacionEmpresa = rs.getString("ubicacion_empresa");
            Empresas empresa = new Empresas(idEmpresa, nombreEmpresa, ubicacionEmpresa);
            empresas.add(empresa);
        }
    } catch (SQLException ex) {
        System.out.println("Error al listar empresas: " + ex.getMessage());
    } finally {
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        } catch (SQLException ex) {
            System.out.println("Error al cerrar la conexión: " + ex.getMessage());
        }
    }
    return empresas;
}

public ArrayList<Empresas> obtenerEmpresas() {
    return listarEmpresas();
}
}
