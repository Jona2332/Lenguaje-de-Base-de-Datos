/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ConexionSQLDev;

import MainClasses.ContactoEmpresas;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author jonha
 */
public class ContactoEmpresaDB {
    public static void insertarContactoEmpresa(ContactoEmpresas contactoempresa)  {
        try {
            
            Connection conn = DBConn.getConnection();
        
            CallableStatement stmt = conn.prepareCall("{call insertar_contacto_empresa(?, ?, ?, ?)}"); 

            stmt.setInt(1, contactoempresa.getId_contacto());
            stmt.setInt(2, contactoempresa.getId_empresa());
            stmt.setString(3, contactoempresa.getNombre_contacto());
            stmt.setString(4, contactoempresa.getTelefono());
            stmt.execute();

        } catch (SQLException ex) {
        System.out.println(ex.getMessage());
        System.out.println("Error en la insercion");
        }
    }
    
    public static void modificarContactoEmpresa(ContactoEmpresas contactoempresa) {
    try {
        
        Connection conn = DBConn.getConnection();
        CallableStatement stmt = conn.prepareCall("{call modificar_contacto_empresa(?, ?, ?, ?)}"); 

        stmt.setInt(1, contactoempresa.getId_contacto());
        stmt.setInt(2, contactoempresa.getId_empresa());
        stmt.setString(3, contactoempresa.getNombre_contacto());
        stmt.setString(4, contactoempresa.getTelefono());
        stmt.execute();

    } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            System.out.println("Error en la actualización");
    }
}
      
    public static void eliminarContactoEmpresa(int idContacto) {
    try (Connection conn = DBConn.getConnection();
         CallableStatement stmt = conn.prepareCall("{CALL eliminar_contacto_empresa(?)}")) {
        stmt.setInt(1, idContacto);
        stmt.executeUpdate();
    } catch (SQLException ex) {
        System.out.println(ex.getMessage());
    }
}

public ArrayList <ContactoEmpresas> listarContactosEmpresa() {
    ArrayList<ContactoEmpresas> contactos = new ArrayList<>();
    try (Connection conn = DBConn.getConnection();
         CallableStatement stmt = conn.prepareCall("{CALL listar_contactos_empresa}")) {
        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            int idContacto = rs.getInt("id_contacto");
            int idEmpresa = rs.getInt("id_empresa");
            String nombreContacto = rs.getString("nombre_contacto");
            String telefono = rs.getString("telefono");
            contactos.add(new ContactoEmpresas(idContacto, idEmpresa, nombreContacto, telefono));
        }
    } catch (SQLException ex) {
        System.out.println(ex.getMessage());
    }
    return contactos;
}
}

