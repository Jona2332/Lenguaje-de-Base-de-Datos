/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainClasses;

/**
 *
 * @author jonha
 */
public class Empresas {
    private int id_empresa;
    private String nombre_empresa;
    private String ubicacion_empresa;

    public Empresas(int id_empresa, String nombre_empresa, String ubicacion_empresa) {
        this.id_empresa = id_empresa;
        this.nombre_empresa = nombre_empresa;
        this.ubicacion_empresa = ubicacion_empresa;
    }

    public Empresas() {
    }

    public int getId_empresa() {
        return id_empresa;
    }

    public void setId_empresa(int id_empresa) {
        this.id_empresa = id_empresa;
    }

    public String getNombre_empresa() {
        return nombre_empresa;
    }

    public void setNombre_empresa(String nombre_empresa) {
        this.nombre_empresa = nombre_empresa;
    }

    public String getUbicacion_empresa() {
        return ubicacion_empresa;
    }

    public void setUbicacion_empresa(String ubicacion_empresa) {
        this.ubicacion_empresa = ubicacion_empresa;
    }
    
}
