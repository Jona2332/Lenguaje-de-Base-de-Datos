/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainClasses;

/**
 *
 * @author jonha
 */
public class ContactoEmpresas {
    private int id_contacto;
    private int id_empresa;
    private String nombre_contacto;
    private String telefono;

    public ContactoEmpresas() {
    }

    public ContactoEmpresas(int id_contacto, int id_empresa, String nombre_contacto, String telefono) {
        this.id_contacto = id_contacto;
        this.id_empresa = id_empresa;
        this.nombre_contacto = nombre_contacto;
        this.telefono = telefono;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public int getId_contacto() {
        return id_contacto;
    }

    public void setId_contacto(int id_contacto) {
        this.id_contacto = id_contacto;
    }

    public int getId_empresa() {
        return id_empresa;
    }

    public void setId_empresa(int id_empresa) {
        this.id_empresa = id_empresa;
    }

    public String getNombre_contacto() {
        return nombre_contacto;
    }

    public void setNombre_contacto(String nombre_contacto) {
        this.nombre_contacto = nombre_contacto;
    }
    
}
