/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainClasses;

/**
 *
 * @author jonha
 */
public class DetalleCompras {
  private int id_detalle_compra;
  private int id_compra;
  private int codigo_producto;
  private int cantidad;
  private float precio_compra;

    public DetalleCompras() {
    }

    public DetalleCompras(int id_detalle_compra, int id_compra, int codigo_producto, int cantidad, float precio_compra) {
        this.id_detalle_compra = id_detalle_compra;
        this.id_compra = id_compra;
        this.codigo_producto = codigo_producto;
        this.cantidad = cantidad;
        this.precio_compra = precio_compra;
    }

    public float getPrecio_compra() {
        return precio_compra;
    }

    public void setPrecio_compra(float precio_compra) {
        this.precio_compra = precio_compra;
    }

    public int getId_detalle_compra() {
        return id_detalle_compra;
    }

    public void setId_detalle_compra(int id_detalle_compra) {
        this.id_detalle_compra = id_detalle_compra;
    }

    public int getId_compra() {
        return id_compra;
    }

    public void setId_compra(int id_compra) {
        this.id_compra = id_compra;
    }

    public int getCodigo_producto() {
        return codigo_producto;
    }

    public void setCodigo_producto(int codigo_producto) {
        this.codigo_producto = codigo_producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
  
}
