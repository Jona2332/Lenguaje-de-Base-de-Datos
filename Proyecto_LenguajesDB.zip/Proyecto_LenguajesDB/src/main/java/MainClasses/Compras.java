/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainClasses;

import java.util.Date;

/**
 *
 * @author jonha
 */
public class Compras {
    private int id_compra;
    private int id_empleado;
    private int id_empresa;
    private float monto;
    private String fecha;

    public Compras() {
    }

    public Compras(int id_compra, int id_empleado, int id_empresa, float monto, String fecha) {
        this.id_compra = id_compra;
        this.id_empleado = id_empleado;
        this.id_empresa = id_empresa;
        this.monto = monto;
        this.fecha = fecha;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getId_compra() {
        return id_compra;
    }

    public void setId_compra(int id_compra) {
        this.id_compra = id_compra;
    }

    public int getId_empleado() {
        return id_empleado;
    }

    public void setId_empleado(int id_empleado) {
        this.id_empleado = id_empleado;
    }

    public int getId_empresa() {
        return id_empresa;
    }

    public void setId_empresa(int id_empresa) {
        this.id_empresa = id_empresa;
    }

    public float getMonto() {
        return monto;
    }

    public void setMonto(float monto) {
        this.monto = monto;
    }
            
}
